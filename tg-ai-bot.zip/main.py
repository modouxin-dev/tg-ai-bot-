"""
Telegram AI Bot - 双模型（Groq / Gemini）可切换
部署到 Render（Web Service + Webhook 模式）

环境变量：
  TELEGRAM_TOKEN   Telegram Bot Token
  GROQ_API_KEY     Groq API Key
  GEMINI_API_KEY   Gemini API Key
"""

import os
import json
import urllib.request
import urllib.parse

# ---------- 从环境变量读取凭证 ----------
TELEGRAM_TOKEN = os.environ.get("TELEGRAM_TOKEN", "")
GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "")
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")

# ---------- 模型配置 ----------
GROQ_MODEL = "llama-3.3-70b-versatile"       # Groq 免费层可用模型，可替换
GEMINI_MODEL = "gemini-2.0-flash"            # Gemini 免费模型，可替换

# 每个用户在内存里记住当前选择的模型（免费实例重启会清空，可接受）
USER_MODEL = {}

# ---------- 工具函数 ----------
def tg_call(method: str, data: dict):
    """调用 Telegram Bot API"""
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/{method}"
    body = json.dumps(data).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def tg_send_message(chat_id: int, text: str):
    """发送文本消息"""
    # 消息太长时 Telegram 会报错，这里简单截断
    if len(text) > 4000:
        text = text[:4000] + "\n...(截断)"
    return tg_call("sendMessage", {"chat_id": chat_id, "text": text})


def groq_chat(messages: list) -> str:
    """调用 Groq 完成对话"""
    url = "https://api.groq.com/openai/v1/chat/completions"
    data = json.dumps({
        "model": GROQ_MODEL,
        "messages": messages,
        "temperature": 0.7,
        "max_tokens": 1000,
    }).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={
        "Content-Type": "application/json",
        "Authorization": f"Bearer {GROQ_API_KEY}",
    })
    with urllib.request.urlopen(req, timeout=60) as resp:
        result = json.loads(resp.read().decode("utf-8"))
    return result["choices"][0]["message"]["content"]


def gemini_chat(messages: list) -> str:
    """调用 Gemini 完成对话"""
    # 把 OpenAI 格式的 messages 转成 Gemini 格式
    contents = []
    system = ""
    for m in messages:
        if m["role"] == "system":
            system = m["content"]
        elif m["role"] == "user":
            contents.append({"role": "user", "parts": [{"text": m["content"]}]})
        elif m["role"] == "assistant":
            contents.append({"role": "model", "parts": [{"text": m["content"]}]})

    url = (f"https://generativelanguage.googleapis.com/v1beta/models/"
           f"{GEMINI_MODEL}:generateContent?key={GEMINI_API_KEY}")
    payload = {"contents": contents}
    if system:
        payload["systemInstruction"] = {"parts": [{"text": system}]}

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as resp:
        result = json.loads(resp.read().decode("utf-8"))
    return result["candidates"][0]["content"]["parts"][0]["text"]


def call_model(chat_id: int, messages: list) -> str:
    """根据用户当前选的模型，调用对应 API"""
    model = USER_MODEL.get(chat_id, "groq")
    if model == "gemini":
        return gemini_chat(messages)
    return groq_chat(messages)


# ---------- 消息处理 ----------
SYSTEM_PROMPT = "你是一个简洁、友好、靠谱的 AI 助手，用中文回答。"

def handle_message(update: dict):
    """处理一条 Telegram Update"""
    message = update.get("message")
    if not message:
        return

    chat_id = message["chat"]["id"]
    text = message.get("text", "").strip()

    # 命令处理
    if text.startswith("/"):
        cmd = text.split()[0].lower()
        if cmd == "/start":
            tg_send_message(chat_id, "你好！我是 AI 助手 🎉\n\n"
                                     "直接发消息即可对话。\n"
                                     "命令：\n"
                                     "/groq 切换到 Groq\n"
                                     "/gemini 切换到 Gemini\n"
                                     "/model 查看当前模型")
        elif cmd in ("/groq", "/gemini"):
            model = cmd[1:]
            USER_MODEL[chat_id] = model
            tg_send_message(chat_id, f"已切换到 {model.upper()} ✅")
        elif cmd == "/model":
            m = USER_MODEL.get(chat_id, "groq")
            tg_send_message(chat_id, f"当前模型：{m.upper()}")
        else:
            tg_send_message(chat_id, "未知命令，可用 /start 查看帮助")
        return

    # 普通对话
    try:
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": text},
        ]
        reply = call_model(chat_id, messages)
        tg_send_message(chat_id, reply)
    except Exception as e:
        tg_send_message(chat_id, f"出错了：{e}")


# ---------- 入口（Render Web Service） ----------
def webhook(event):
    """Render 调用的入口，接收 Telegram webhook"""
    body = event.get("body", "{}")
    update = json.loads(body)
    handle_message(update)
    return {"statusCode": 200, "body": "ok"}


# 本地直接跑时，用轮询模式（方便调试）
if __name__ == "__main__":
    try:
        # 尝试 Flask 方式（Render 需要）
        from flask import Flask, request
        app = Flask(__name__)

        @app.route("/", methods=["GET", "POST"])
        def index():
            if request.method == "POST":
                update = request.get_json()
                handle_message(update)
            return "ok"

        port = int(os.environ.get("PORT", 10000))
        app.run(host="0.0.0.0", port=port)
    except ImportError:
        # 无 Flask 时，用简单轮询（仅本地调试）
        print("Flask 未安装，进入轮询调试模式")
        offset = 0
        while True:
            try:
                updates = tg_call("getUpdates", {"offset": offset, "timeout": 30})
                for u in updates.get("result", []):
                    offset = u["update_id"] + 1
                    handle_message(u)
            except Exception as e:
                print("err:", e)
