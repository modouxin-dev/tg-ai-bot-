# Telegram AI Bot（双模型 Groq / Gemini）

一个跑在 Render 免费层上的 Telegram 机器人，支持 Groq 和 Gemini 两个模型切换。

## 功能
- `/start` 查看帮助
- `/groq` 切换到 Groq
- `/gemini` 切换到 Gemini
- `/model` 查看当前模型
- 直接发消息即可对话

## 部署到 Render

1. 把本目录上传到 GitHub 仓库
2. Render 控制台 → New → Web Service → 连接该仓库
3. Render 会自动读取 `render.yaml`（Blueprint），或手动配置：
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `gunicorn main:app --workers 1 --bind 0.0.0.0:$PORT`
4. 在 Environment 里填入三个环境变量：
   - `TELEGRAM_TOKEN`
   - `GROQ_API_KEY`
   - `GEMINI_API_KEY`
5. 部署完成后，拿到服务的 URL（如 `https://xxx.onrender.com`）

## 设置 Telegram Webhook

部署成功后，把下面的 URL 替换成你的服务地址，在浏览器打开：

```
https://api.telegram.org/bot<你的TOKEN>/setWebhook?url=https://xxx.onrender.com
```

看到 `{"ok":true}` 即成功，之后给机器人发消息就能收到回复。

## 本地调试（可选）

```bash
pip install -r requirements.txt
export TELEGRAM_TOKEN=xxx
export GROQ_API_KEY=xxx
export GEMINI_API_KEY=xxx
python main.py
```
